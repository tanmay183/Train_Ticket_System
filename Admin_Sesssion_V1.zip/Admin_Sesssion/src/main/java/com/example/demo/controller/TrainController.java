package com.example.demo.controller;



import com.example.demo.entity.Train;
import com.example.demo.service.TrainService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/trains")
@CrossOrigin
public class TrainController {
    private final TrainService trainService;

    public TrainController(TrainService trainService) {
        this.trainService = trainService;
    }

    @PostMapping
    public Train addTrain(@RequestBody Train train) {
        return trainService.addTrain(train);
    }

    @PutMapping("/{trainNumber}")
    public Train updateTrain(@PathVariable String trainNumber, @RequestBody Train train) {
        return trainService.updateTrain(trainNumber, train);
    }

    @DeleteMapping("/{trainNumber}")
    public void deleteTrain(@PathVariable String trainNumber) {
        trainService.deleteTrain(trainNumber);
    }

    @GetMapping
    public List<Train> getAllTrains() {
        return trainService.getAllTrains();
    }

    @GetMapping("/search")
    public List<Train> searchTrains(@RequestParam String prefix) {
        return trainService.searchByPrefix(prefix);
    }

    @GetMapping("/{trainNumber}")
    public Train getTrain(@PathVariable String trainNumber) {
        return trainService.getById(trainNumber);
    }
}