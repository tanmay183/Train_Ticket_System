package com.example.demo.service;



import com.example.demo.entity.Train;
import java.util.List;

public interface TrainService {
    Train addTrain(Train train);
    Train updateTrain(String trainNumber, Train train);
    void deleteTrain(String trainNumber);
    List<Train> getAllTrains();
    List<Train> searchByPrefix(String prefix);
    Train getById(String trainNumber);
}