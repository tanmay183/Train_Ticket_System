package com.example.demo.service;



import com.example.demo.entity.Train;
import com.example.demo.repository.TrainRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class TrainServiceImpl implements TrainService {
    private final TrainRepository trainRepo;

    public TrainServiceImpl(TrainRepository trainRepo) {
        this.trainRepo = trainRepo;
    }

    public Train addTrain(Train train) { return trainRepo.save(train); }

    public Train updateTrain(String trainNumber, Train updatedTrain) {
        Train train = trainRepo.findById(trainNumber).orElseThrow();
        updatedTrain.setTrainNumber(trainNumber);
        return trainRepo.save(updatedTrain);
    }

    public void deleteTrain(String trainNumber) { trainRepo.deleteById(trainNumber); }

    public List<Train> getAllTrains() { return trainRepo.findAll(); }

    public List<Train> searchByPrefix(String prefix) {
        return trainRepo.findByNameStartsWithIgnoreCase(prefix);
    }

    public Train getById(String trainNumber) {
        return trainRepo.findById(trainNumber).orElse(null);
    }
}